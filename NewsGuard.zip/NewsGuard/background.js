// ============================================================
//  PROP FIRM NEWS GUARD — Background Service Worker
//  Monitors the economic calendar and fires Chrome notifications
//  30 minutes before any high-impact (Red Folder) news event.
// ============================================================

const API_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.json";

// ---------- Lifecycle ----------

chrome.runtime.onInstalled.addListener(() => {
  console.log("[NewsGuard] Extension installed.");
  setupAlarms();
  fetchAndStoreEvents();
  setExtensionIcon();
});

chrome.runtime.onStartup.addListener(() => {
  console.log("[NewsGuard] Browser started.");
  setupAlarms();
  fetchAndStoreEvents();
  setExtensionIcon();
});

function setupAlarms() {
  // Check every minute for approaching events
  chrome.alarms.create("tickCheck", { delayInMinutes: 0.1, periodInMinutes: 1 });
  // Refresh calendar data every 30 minutes
  chrome.alarms.create("refreshData", { delayInMinutes: 0.5, periodInMinutes: 30 });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "tickCheck") checkUpcomingEvents();
  if (alarm.name === "refreshData") fetchAndStoreEvents();
});

// ---------- Data Fetching ----------

async function fetchAndStoreEvents() {
  try {
    const res = await fetch(API_URL);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const all = await res.json();

    const highImpact = all.filter(
      (e) => e.impact && e.impact.toLowerCase() === "high"
    );

    await chrome.storage.local.set({ events: highImpact, lastFetch: Date.now() });
    console.log(`[NewsGuard] Stored ${highImpact.length} high-impact events.`);
  } catch (err) {
    console.error("[NewsGuard] Fetch failed:", err);
  }
}

// ---------- Event Monitoring ----------

async function checkUpcomingEvents() {
  try {
    const { events = [], notifiedIds = [] } = await chrome.storage.local.get([
      "events",
      "notifiedIds",
    ]);

    const now = new Date();
    const todayStr = localDateStr(now);
    let closestMinutes = Infinity;

    for (const ev of events) {
      const t = safeDate(ev);
      if (!t) continue;
      if (localDateStr(t) !== todayStr) continue;

      const diffMs = t - now;
      const mins = diffMs / 60000;

      if (mins > 0 && mins < closestMinutes) closestMinutes = mins;

      const uid = `${ev.title}|${ev.date}|${ev.country}`;

      if (mins > 0 && mins <= 30 && !notifiedIds.includes(uid)) {
        await fireNotification(ev, Math.round(mins));
        notifiedIds.push(uid);
        await chrome.storage.local.set({ notifiedIds });
      }
    }

    // Badge countdown
    if (closestMinutes <= 30 && closestMinutes > 0) {
      const label = closestMinutes < 1 ? "<1" : String(Math.round(closestMinutes));
      chrome.action.setBadgeText({ text: label + "m" });
      chrome.action.setBadgeBackgroundColor({
        color: closestMinutes <= 5 ? "#FF3366" : closestMinutes <= 15 ? "#FF8800" : "#FF6600",
      });
    } else {
      chrome.action.setBadgeText({ text: "" });
    }

    // Daily cleanup of notified list
    const { lastCleanup } = await chrome.storage.local.get("lastCleanup");
    if (!lastCleanup || localDateStr(new Date(lastCleanup)) !== todayStr) {
      await chrome.storage.local.set({ notifiedIds: [], lastCleanup: Date.now() });
    }
  } catch (err) {
    console.error("[NewsGuard] Check error:", err);
  }
}

// ---------- Notifications ----------

async function fireNotification(ev, minsLeft) {
  const timeLabel = safeDate(ev)?.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  }) || "??:??";

  const id = "pfng_" + Date.now();
  const iconUrl = await getNotifIcon();

  const opts = {
    type: "basic",
    iconUrl,
    title: "\u{1F534} HIGH-IMPACT NEWS IN " + minsLeft + " MIN",
    message: `${ev.country || "?"} \u2014 ${ev.title}\n\u23F0 Scheduled at ${timeLabel}\n\n\u26A0\uFE0F Close or hedge your positions NOW!`,
    priority: 2,
    requireInteraction: true,
  };

  chrome.notifications.create(id, opts, () => {
    if (chrome.runtime.lastError)
      console.warn("[NewsGuard] Notif error:", chrome.runtime.lastError.message);
  });
}

// ---------- Dynamic Icon Generation ----------

async function setExtensionIcon() {
  try {
    const sizes = [16, 32, 48];
    const imageDataMap = {};
    for (const s of sizes) imageDataMap[s] = drawShieldImageData(s);
    chrome.action.setIcon({ imageData: imageDataMap });
  } catch (e) {
    console.warn("[NewsGuard] Icon set failed:", e);
  }
}

function drawShieldImageData(s) {
  const c = new OffscreenCanvas(s, s);
  const x = c.getContext("2d");

  // background
  x.fillStyle = "#0B0E14";
  x.fillRect(0, 0, s, s);

  const m = s / 32; // scale multiplier

  // outer shield
  x.fillStyle = "#00F5FF";
  x.beginPath();
  x.moveTo(16 * m, 2 * m);
  x.lineTo(28 * m, 8 * m);
  x.lineTo(28 * m, 18 * m);
  x.quadraticCurveTo(28 * m, 29 * m, 16 * m, 31 * m);
  x.quadraticCurveTo(4 * m, 29 * m, 4 * m, 18 * m);
  x.lineTo(4 * m, 8 * m);
  x.closePath();
  x.fill();

  // inner shield cutout
  x.fillStyle = "#0B0E14";
  x.beginPath();
  x.moveTo(16 * m, 6 * m);
  x.lineTo(24 * m, 10 * m);
  x.lineTo(24 * m, 17 * m);
  x.quadraticCurveTo(24 * m, 26 * m, 16 * m, 28 * m);
  x.quadraticCurveTo(8 * m, 26 * m, 8 * m, 17 * m);
  x.lineTo(8 * m, 10 * m);
  x.closePath();
  x.fill();

  // exclamation mark
  x.fillStyle = "#00F5FF";
  x.fillRect(14.5 * m, 11 * m, 3 * m, 9 * m);
  x.beginPath();
  x.arc(16 * m, 23.5 * m, 2 * m, 0, Math.PI * 2);
  x.fill();

  return x.getImageData(0, 0, s, s);
}

async function getNotifIcon() {
  try {
    // Check cache first
    const { cachedNotifIcon } = await chrome.storage.local.get("cachedNotifIcon");
    if (cachedNotifIcon) return cachedNotifIcon;

    const s = 128;
    const c = new OffscreenCanvas(s, s);
    const x = c.getContext("2d");

    // circular bg
    x.fillStyle = "#0B0E14";
    x.beginPath();
    x.arc(64, 64, 64, 0, Math.PI * 2);
    x.fill();

    // outer shield
    x.fillStyle = "#00F5FF";
    x.beginPath();
    x.moveTo(64, 10);
    x.lineTo(108, 30);
    x.lineTo(108, 66);
    x.quadraticCurveTo(108, 110, 64, 122);
    x.quadraticCurveTo(20, 110, 20, 66);
    x.lineTo(20, 30);
    x.closePath();
    x.fill();

    // inner shield
    x.fillStyle = "#0B0E14";
    x.beginPath();
    x.moveTo(64, 24);
    x.lineTo(96, 38);
    x.lineTo(96, 64);
    x.quadraticCurveTo(96, 100, 64, 110);
    x.quadraticCurveTo(32, 100, 32, 64);
    x.lineTo(32, 38);
    x.closePath();
    x.fill();

    // warning triangle
    x.fillStyle = "#FF3366";
    x.beginPath();
    x.moveTo(64, 42);
    x.lineTo(90, 90);
    x.lineTo(38, 90);
    x.closePath();
    x.fill();

    x.fillStyle = "#0B0E14";
    x.beginPath();
    x.moveTo(64, 54);
    x.lineTo(82, 84);
    x.lineTo(46, 84);
    x.closePath();
    x.fill();

    x.fillStyle = "#FF3366";
    x.fillRect(61, 60, 6, 12);
    x.beginPath();
    x.arc(64, 78, 3.5, 0, Math.PI * 2);
    x.fill();

    const blob = await c.convertToBlob({ type: "image/png" });
    const buf = await blob.arrayBuffer();
    const bytes = new Uint8Array(buf);
    let bin = "";
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    const dataUrl = "data:image/png;base64," + btoa(bin);

    await chrome.storage.local.set({ cachedNotifIcon: dataUrl });
    return dataUrl;
  } catch (e) {
    console.warn("[NewsGuard] Icon gen failed:", e);
    return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQI12NgAAIABQABNjN9GQAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAA0lEQVQI12P4z8BQDwAEgAF/QualzQAAAABJRU5ErkJggg==";
  }
}

// ---------- Helpers ----------

function safeDate(ev) {
  if (!ev || !ev.date) return null;
  const d = new Date(ev.date);
  return isNaN(d.getTime()) ? null : d;
}

function localDateStr(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}