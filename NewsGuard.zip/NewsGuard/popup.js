// ============================================================
//  PROP FIRM NEWS GUARD — Popup Controller
//  Renders today's high-impact events with live countdown.
// ============================================================

const API = "https://nfs.faireconomy.media/ff_calendar_thisweek.json";
const $app = document.getElementById("app");
const $upd = document.getElementById("upd");
const $ref = document.getElementById("ref");

const FLAGS = {
  USD:"🇺🇸", EUR:"🇪🇺", GBP:"🇬🇧", JPY:"🇯🇵", AUD:"🇦🇺",
  NZD:"🇳🇿", CAD:"🇨🇦", CHF:"🇨🇭", CNY:"🇨🇳", ALL:"🌐"
};
const flag = c => FLAGS[c] || "🌐";

let evts = [];      // today's high-impact events (sorted)
let tickId = null;   // countdown interval handle

// ---------- Boot ----------
document.addEventListener("DOMContentLoaded", init);
$ref.addEventListener("click", () => load(true));

async function init() { await load(); startTick(); }

// ---------- Data ----------
async function load(force = false) {
  showLoading();
  try {
    let data;

    // 1) Try cache
    if (!force) {
      const c = await chrome.storage.local.get(["events", "lastFetch"]);
      if (c.events && c.lastFetch && Date.now() - c.lastFetch < 15 * 60000)
        data = c.events;
    }

    // 2) Fetch fresh
    if (!data) {
      const r = await fetch(API);
      if (!r.ok) throw new Error("HTTP " + r.status);
      const all = await r.json();
      data = all.filter(e => e.impact && e.impact.toLowerCase() === "high");
      await chrome.storage.local.set({ events: data, lastFetch: Date.now() });
    }

    // 3) Filter today & sort
    const todayKey = ymd(new Date());
    evts = data
      .map(e => ({ ...e, _t: safe(e) }))
      .filter(e => e._t && ymd(e._t) === todayKey)
      .sort((a, b) => a._t - b._t);

    render();
    $upd.textContent = "Updated " + new Date().toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" });
  } catch (err) {
    showError(err.message);
  }
}

// ---------- Rendering ----------
function render() {
  if (!evts.length) return showEmpty();

  const now = new Date();
  const next = evts.find(e => e._t > now);
  let h = "";

  // Countdown
  if (next) {
    const diff = next._t - now;
    const mins = diff / 60000;
    h += `<div class="cd-wrap">
      <div class="cd-label">Next High-Impact Event</div>
      <div class="cd-time" id="cd" data-iso="${next._t.toISOString()}">${fmtCD(diff)}</div>
      <div class="cd-event"><span class="cd-cur">${flag(next.country)} ${next.country||""}</span> &mdash; ${esc(next.title)}</div>
    </div>`;
    if (mins <= 30)
      h += `<div class="warn${mins <= 5 ? " hot" : ""}">⚡ Event in ~${Math.ceil(mins)} min — Consider closing or hedging positions!</div>`;
  } else {
    h += `<div class="cd-wrap">
      <div class="cd-label">All Events Passed</div>
      <div class="cd-clear">✓ CLEAR</div>
      <div class="cd-sub">No more high-impact news today</div>
    </div>`;
  }

  // Event list
  h += `<div class="sec">Today's Red-Folder Events (${evts.length})</div><div class="list">`;
  for (const e of evts) {
    const passed = e._t < now;
    const t = e._t.toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" });
    h += `<div class="card${passed ? " done" : ""}">
      <div class="row">
        <span class="time">${t}</span>
        <span class="cur"><span class="cur-flag">${flag(e.country)}</span>${e.country||"—"}</span>
      </div>
      <div class="name">${esc(e.title)}</div>
      <div class="meta">
        <span class="imp"><i></i>High Impact</span>
        ${e.forecast ? `<span>Fcst: <strong>${esc(e.forecast)}</strong></span>` : ""}
        ${e.previous ? `<span>Prev: <strong>${esc(e.previous)}</strong></span>` : ""}
      </div>
    </div>`;
  }
  h += "</div>";

  $app.innerHTML = h;
}

// ---------- Countdown Tick ----------
function startTick() {
  if (tickId) clearInterval(tickId);
  tickId = setInterval(() => {
    const el = document.getElementById("cd");
    if (!el) return;
    const target = new Date(el.dataset.iso);
    const diff = target - new Date();
    if (diff <= 0) {
      el.textContent = "00 : 00 : 00";
      el.style.color = "#ff3366";
      clearInterval(tickId);
      setTimeout(() => { render(); startTick(); }, 2000);
      return;
    }
    el.textContent = fmtCD(diff);

    // Color shift
    const m = diff / 60000;
    if (m <= 5)       { el.style.color="#ff3366"; el.style.textShadow="0 0 24px #ff336640"; }
    else if (m <= 15) { el.style.color="#ffaa00"; el.style.textShadow="0 0 24px #ffaa0030"; }
    else if (m <= 30) { el.style.color="#ff8800"; el.style.textShadow="0 0 24px #ff880025"; }
    else              { el.style.color="#fff";    el.style.textShadow="0 0 28px #00f5ff30"; }
  }, 1000);
}

// ---------- State Views ----------
function showLoading() {
  $app.innerHTML = `<div class="ld"><div class="spinner"></div><div class="ld-t">Scanning Calendar&hellip;</div></div>`;
}
function showEmpty() {
  $app.innerHTML = `<div class="empty">
    <div class="empty-ico">🛡️</div>
    <div class="empty-t">No High-Impact News Today</div>
    <div class="empty-s">You're clear to trade freely</div>
  </div>`;
}
function showError(msg) {
  $app.innerHTML = `<div class="err">
    <div class="err-ico">⚠️</div>
    <div class="err-t">Failed to Load Calendar</div>
    <div class="err-s">${esc(msg)}</div>
  </div>`;
}

// ---------- Helpers ----------
function safe(e) {
  if (!e || !e.date) return null;
  const d = new Date(e.date);
  return isNaN(d.getTime()) ? null : d;
}
function ymd(d) {
  return d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
}
function fmtCD(ms) {
  if (ms <= 0) return "00 : 00 : 00";
  const h = String(Math.floor(ms/3600000)).padStart(2,"0");
  const m = String(Math.floor((ms%3600000)/60000)).padStart(2,"0");
  const s = String(Math.floor((ms%60000)/1000)).padStart(2,"0");
  return `${h} : ${m} : ${s}`;
}
function esc(s) {
  if (!s) return "";
  const d = document.createElement("div"); d.textContent = s; return d.innerHTML;
}